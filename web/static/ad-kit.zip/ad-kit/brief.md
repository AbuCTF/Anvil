# attack-defense

- vpn on for everything below
- your box address and team number are on the operations page. log in with `ssh ubuntu@<your box>`
- services on every box: 7001 sign me in, 7002 can we settle this, 7003 update pending (tcp), 7004 book me if you can, 7005 ship it
- other teams: `10.60.BB.2:PORT`, the targets table on the operations page lists them all
- box 16 is the nop: nobody defends it, use it to test exploits. its flags score nothing
- a tick is 2 min. every tick each service gets fresh flags. a flag can be submitted for 5 ticks (10 min), then it expires
- flags look like `H7CTF{...}`
- flag ids: https://finals.h7tex.com/api/v1/arena/attack-info lists, per service and box, the public hints (a username, an id) that point to each live flag
- submit on the operations page, or run submit.py with `TEAM_TOKEN` set to the token shown there
- attack team boxes only. no dos, no hitting the gateway or the platform
