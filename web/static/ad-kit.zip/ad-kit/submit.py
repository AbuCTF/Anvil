#!/usr/bin/env python3
import json
import os
import re
import sys
import urllib.request

URL = "https://finals.h7tex.com/api/v1/arena/flags"
FLAG = re.compile(r"H7CTF\{[^}\s]{1,120}\}")


def submit(token, flags):
    out = []
    for i in range(0, len(flags), 500):
        req = urllib.request.Request(URL, method="PUT", data=json.dumps(flags[i:i + 500]).encode())
        req.add_header("X-Team-Token", token)
        req.add_header("Content-Type", "application/json")
        with urllib.request.urlopen(req, timeout=20) as r:
            out += json.loads(r.read())
    return out


def main():
    token = os.environ.get("TEAM_TOKEN", "").strip()
    if not token:
        sys.exit("set TEAM_TOKEN")
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else sys.stdin.read()
    flags = list(dict.fromkeys(FLAG.findall(text)))
    if not flags:
        sys.exit("no flags")
    for r in submit(token, flags):
        print(r["status"], r["flag"])


if __name__ == "__main__":
    main()
